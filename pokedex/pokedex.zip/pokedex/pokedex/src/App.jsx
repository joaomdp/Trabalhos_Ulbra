import './output.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Importando os componentes das páginas
import Home from './pages/Home';
import Pokedex from './pages/Pokedex';  // Página de Pokédex
import Legendaries from './pages/Legendaries';  // Página de Legendaries
import Documentation from './pages/Documentation';  // Página de Documentation

// Importando o Header com links de navegação
import Header from './components/Header';

const App = () => {
  return (
    <Router>
      <Header />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/pokedex" element={<Pokedex />} />
        <Route path="/legendaries" element={<Legendaries />} />
        <Route path="/documentation" element={<Documentation />} />
      </Routes>
    </Router>
  );
};

export default App;
