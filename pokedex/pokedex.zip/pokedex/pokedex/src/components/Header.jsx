import { Link } from 'react-router-dom';  // Importe o Link do React Router
import Logo from "../assets/img/logo-pokemon.svg";

const Header = () => {
  return (
    <header className="bg-yellow-300 border-black drop-shadow-lg">
      <div className="container mx-auto flex justify-between items-center py-4 px-6">
        {/* Logo */}
        <div className="flex items-center">
          <img src={Logo} alt="Pokémon Logo" className="h-10" />
        </div>

        <nav className="flex space-x-8 text-black font-bold">
          {/* Usando Link do React Router para navegação */}
          <Link
            to="/"
            className="hover:underline underline-offset-4 decoration-2 decoration-black"
          >
            Home
          </Link>
          <Link
            to="/pokedex"
            className="hover:underline underline-offset-4 decoration-2 decoration-black"
          >
            Pokédex
          </Link>
          <Link
            to="/legendaries"
            className="hover:underline underline-offset-4 decoration-2 decoration-black"
          >
            Legendaries
          </Link>
          <Link
            to="/documentation"
            className="hover:underline underline-offset-4 decoration-2 decoration-black"
          >
            Documentation
          </Link>
        </nav>
      </div>
    </header>
  );
};

export default Header;
