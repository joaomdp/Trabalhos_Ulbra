import React from 'react';

const Documentation = () => {
  return <h2 className="text-xl">Documentation Page</h2>;
};

export default Documentation;  
