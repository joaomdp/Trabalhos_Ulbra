import React from 'react';

const Legendaries = () => {
  return <h2 className="text-xl">Legendaries</h2>;
};

export default Legendaries;  
