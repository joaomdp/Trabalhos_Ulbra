import React from 'react';
import PokemonList from '../components/PokemonList';

const Pokedex = () => {
  return (
    <PokemonList />
  )
};

export default Pokedex;  
